
//#include "fsl_sdmmc_common.h"


//#define READ_WRITE_BUFOR_SIZE 9600

//uint8_t g_bufferReadWrite[9600];

////SDK_ALIGN(uint8_t g_bufferReadWrite[SDK_SIZEALIGN(READ_WRITE_BUFOR_SIZE, SDMMC_DATA_BUFFER_ALIGN_CACHE)],
//          MAX(SDMMC_DATA_BUFFER_ALIGN_CACHE, SDMMCHOST_DMA_BUFFER_ADDR_ALIGN));

